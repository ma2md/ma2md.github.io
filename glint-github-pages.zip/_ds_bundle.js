/* @ds-bundle: {"format":4,"namespace":"AteliDoValeDesignSystem_a6a127","components":[{"name":"Scenery","sourcePath":"components/atmosphere/Scenery.jsx"},{"name":"SnowField","sourcePath":"components/atmosphere/SnowField.jsx"},{"name":"Wordmark","sourcePath":"components/brand/Wordmark.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"EmojiTile","sourcePath":"components/emoji/EmojiTile.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"ColorSwatches","sourcePath":"components/forms/ColorSwatches.jsx"},{"name":"FrameSelector","sourcePath":"components/forms/FrameSelector.jsx"},{"name":"SegmentedControl","sourcePath":"components/forms/SegmentedControl.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Slider","sourcePath":"components/forms/Slider.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Panel","sourcePath":"components/surfaces/Panel.jsx"},{"name":"PreviewFrame","sourcePath":"components/surfaces/PreviewFrame.jsx"},{"name":"SparkleBanner","sourcePath":"components/surfaces/SparkleBanner.jsx"},{"name":"Tag","sourcePath":"components/surfaces/Tag.jsx"}],"sourceHashes":{"components/atmosphere/Scenery.jsx":"234f3b72cb24","components/atmosphere/SnowField.jsx":"350ff7fad429","components/brand/Wordmark.jsx":"098e317ee3ad","components/core/Button.jsx":"90c2fb3de815","components/core/Icon.jsx":"836811aeb79f","components/core/IconButton.jsx":"9996f76ccbf3","components/emoji/EmojiTile.jsx":"2d043eeb07e2","components/feedback/Toast.jsx":"894014f653a8","components/feedback/Tooltip.jsx":"c7b9e7df37a3","components/forms/Checkbox.jsx":"94aa70ef8cfd","components/forms/ColorSwatches.jsx":"980244b10b0a","components/forms/FrameSelector.jsx":"9daf01badf56","components/forms/SegmentedControl.jsx":"0ed4a53ffbaf","components/forms/Select.jsx":"6478239bdaca","components/forms/Slider.jsx":"2f6f329bdf91","components/forms/Switch.jsx":"953623ece1da","components/forms/TextField.jsx":"36377dd1ddf4","components/navigation/NavBar.jsx":"33b76fdafccc","components/navigation/Tabs.jsx":"160a79d922a8","components/surfaces/Panel.jsx":"9a18c1e4a2c8","components/surfaces/PreviewFrame.jsx":"1c286650130a","components/surfaces/SparkleBanner.jsx":"fed17c4ee206","components/surfaces/Tag.jsx":"8d6c5da9dd59","ui_kits/web/EditorScreen.jsx":"ef71d5fd395e","ui_kits/web/GalleryScreen.jsx":"dd7d0730fd4f","ui_kits/web/lib/gif.js":"50f9c8487211","ui_kits/web/lib/scroll-renderer.js":"3c7a7797f653","ui_kits/web/lib/sprite-links.js":"cd955db1d5de","ui_kits/web/lib/sprites.js":"9e09c5486a26"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AteliDoValeDesignSystem_a6a127 = window.AteliDoValeDesignSystem_a6a127 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/atmosphere/SnowField.jsx
try { (() => {
function SnowField({
  density = 70,
  speed = 1,
  glints = true,
  color = '238,243,247',
  glintColor = '255,255,255',
  rise = false,
  style
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let w = 0,
      h = 0,
      raf,
      flakes = [];
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => {
      w = cv.clientWidth;
      h = cv.clientHeight;
      cv.width = w * dpr;
      cv.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const make = y => ({
      x: Math.random() * w,
      y: y ?? Math.random() * h,
      r: Math.random() * 1.4 + .4,
      vy: Math.random() * .25 + .12,
      sway: Math.random() * Math.PI * 2,
      a: Math.random() * .5 + .25,
      glint: glints && Math.random() < .035
    });
    resize();
    flakes = Array.from({
      length: density
    }, () => make());
    const draw = t => {
      ctx.clearRect(0, 0, w, h);
      for (const f of flakes) {
        if (!reduce) {
          f.y += (rise ? -f.vy * .45 : f.vy) * speed;
          f.x += Math.sin(t / 2400 + f.sway) * (rise ? .2 : .12) * speed;
          if (!rise && f.y > h + 4) Object.assign(f, make(-4));
          if (rise && f.y < -4) Object.assign(f, make(h + 4));
        }
        if (f.glint) {
          const tw = reduce ? .7 : (Math.sin(t / 1300 + f.sway * 3) + 1) / 2;
          ctx.globalAlpha = .25 + tw * .6;
          ctx.fillStyle = 'rgb(' + glintColor + ')';
          ctx.fillRect(f.x - .5, f.y - 3, 1, 6);
          ctx.fillRect(f.x - 3, f.y - .5, 6, 1);
        } else {
          ctx.globalAlpha = f.a;
          ctx.fillStyle = 'rgb(' + color + ')';
          ctx.beginPath();
          ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      if (!reduce) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, [density, speed, glints, color, glintColor, rise]);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      ...style
    }
  });
}
Object.assign(__ds_scope, { SnowField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/atmosphere/SnowField.jsx", error: String((e && e.message) || e) }); }

// components/atmosphere/Scenery.jsx
try { (() => {
function summerVideoUrl() {
  const link = typeof document !== 'undefined' && Array.from(document.querySelectorAll('link[rel="stylesheet"]')).find(l => /styles\.css(\?|$)/.test(l.href));
  return link ? new URL('assets/summer/lake.webm', link.href).href : null;
}
function Scenery({
  season = 'winter',
  snow = true,
  density,
  fixed = true,
  videoSrc,
  children,
  style
}) {
  const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const summer = season === 'summer';
  const [src] = React.useState(() => videoSrc || (summer ? summerVideoUrl() : null));
  const video = summer ? videoSrc || src || summerVideoUrl() : null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      minHeight: fixed ? '100vh' : undefined,
      isolation: 'isolate',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: 'adv-scenery' + (summer ? ' adv-scenery--summer' : ''),
    style: fixed ? undefined : {
      position: 'absolute'
    },
    "aria-hidden": "true"
  }, summer && video && !reduce && /*#__PURE__*/React.createElement("video", {
    className: "adv-scenery__video",
    src: video,
    autoPlay: true,
    muted: true,
    loop: true,
    playsInline: true
  }), /*#__PURE__*/React.createElement("span", {
    className: "adv-sprite adv-sprite--bunny",
    style: {
      left: 8,
      bottom: 8
    }
  }), snow && (summer ? /*#__PURE__*/React.createElement(__ds_scope.SnowField, {
    density: density ?? 34,
    color: "255,238,184",
    glints: false,
    rise: true
  }) : /*#__PURE__*/React.createElement(__ds_scope.SnowField, {
    density: density ?? 70,
    glints: false
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, children));
}
Object.assign(__ds_scope, { Scenery });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/atmosphere/Scenery.jsx", error: String((e && e.message) || e) }); }

// components/brand/Wordmark.jsx
try { (() => {
function Wordmark({
  size = 20,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: 'adv-wm' + (size < 28 ? ' adv-wm--sm' : ''),
    style: {
      fontSize: size,
      ...style
    },
    "aria-label": "glint",
    role: "img"
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-wm__t",
    "aria-hidden": "true"
  }, "glint"), /*#__PURE__*/React.createElement("span", {
    className: "adv-wm__s",
    "aria-hidden": "true"
  }));
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function Icon({
  name,
  size = 15,
  style,
  className = ''
}) {
  return /*#__PURE__*/React.createElement("i", {
    "aria-hidden": "true",
    className: 'icon-' + name + ' ' + className,
    style: {
      fontSize: size,
      lineHeight: 1,
      display: 'inline-block',
      fontStyle: 'normal',
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = 'secondary',
  size = 'md',
  icon,
  iconRight,
  selected = false,
  glint,
  disabled,
  type = 'button',
  onClick,
  children,
  style,
  ...rest
}) {
  const cls = ['adv-btn', variant !== 'secondary' && 'adv-btn--' + variant, size !== 'md' && 'adv-btn--' + size, selected && 'is-selected'].filter(Boolean).join(' ');
  const showGlint = glint ?? (selected || variant === 'primary');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls,
    disabled: disabled,
    onClick: onClick,
    "aria-pressed": selected || undefined,
    style: style
  }, rest), variant === 'primary' && /*#__PURE__*/React.createElement("span", {
    className: "adv-sheen",
    "aria-hidden": "true"
  }), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 13 : 14
  }), children != null && /*#__PURE__*/React.createElement("span", null, children), iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: size === 'sm' ? 13 : 14
  }), showGlint && !disabled && /*#__PURE__*/React.createElement("span", {
    className: "adv-glint-mark"
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function IconButton({
  icon,
  label,
  size = 'md',
  variant = 'secondary',
  selected = false,
  disabled,
  onClick,
  style
}) {
  const cls = ['adv-btn', 'adv-btn--icon', variant !== 'secondary' && 'adv-btn--' + variant, size !== 'md' && 'adv-btn--' + size, selected && 'is-selected'].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: cls,
    "aria-label": label,
    title: label,
    "aria-pressed": selected || undefined,
    disabled: disabled,
    onClick: onClick,
    style: style
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 13 : 15
  }), selected && /*#__PURE__*/React.createElement("span", {
    className: "adv-glint-mark"
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/emoji/EmojiTile.jsx
try { (() => {
function EmojiTile({
  name,
  src,
  code,
  animated = false,
  selected = false,
  onClick,
  size = 32,
  style
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'adv-emoji' + (selected ? ' is-selected' : ''),
    "aria-pressed": selected,
    onClick: onClick,
    title: code || name,
    style: style
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    width: size,
    height: size,
    className: "adv-pixel",
    style: {
      imageRendering: 'pixelated',
      width: size,
      height: size,
      objectFit: 'contain'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      boxSizing: 'border-box',
      border: '1px dashed var(--border-strong)',
      display: 'grid',
      placeItems: 'center',
      font: 'var(--type-mono)',
      fontSize: 9,
      color: 'var(--text-faint)'
    }
  }, size), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-label)',
      color: selected ? 'var(--text-strong)' : 'var(--text-muted)',
      maxWidth: '100%',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, name), animated && /*#__PURE__*/React.createElement("span", {
    className: "adv-mono",
    style: {
      position: 'absolute',
      top: 5,
      right: 6,
      fontSize: 9,
      letterSpacing: '.08em',
      color: 'var(--accent-strong)'
    }
  }, "GIF"), selected && /*#__PURE__*/React.createElement("span", {
    className: "adv-glint-mark"
  }));
}
Object.assign(__ds_scope, { EmojiTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/emoji/EmojiTile.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  message,
  tone = 'default',
  icon,
  onClose,
  style
}) {
  const dot = {
    default: 'var(--glint)',
    ok: 'var(--frost-ok)',
    error: 'var(--frost-error)'
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    className: "adv-frost",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      padding: '9px 12px',
      background: 'var(--surface-panel-strong)',
      borderRadius: 'var(--radius-1)',
      boxShadow: 'var(--shadow-pop)',
      font: 'var(--type-body-sm)',
      color: 'var(--text-primary)',
      animation: 'adv-fade-in var(--dur) var(--ease-hush) both',
      ...style
    }
  }, icon ? /*#__PURE__*/React.createElement("i", {
    className: 'icon-' + icon,
    style: {
      fontSize: 13,
      color: dot
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      background: dot,
      transform: 'rotate(45deg)',
      boxShadow: tone === 'default' ? '0 0 6px var(--glint-soft)' : 'none'
    }
  }), /*#__PURE__*/React.createElement("span", null, message), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      background: 'none',
      border: 0,
      color: 'var(--text-faint)',
      cursor: 'pointer',
      padding: 0,
      marginLeft: 4
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: "icon-x",
    style: {
      fontSize: 12
    }
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  open,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "adv-tooltip",
    style: style
  }, children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    className: 'adv-tooltip__bubble' + (open ? ' is-open' : '')
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked = false,
  onChange,
  disabled,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: 'adv-check' + (checked ? ' is-on' : '') + (disabled ? ' is-disabled' : ''),
    style: style
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "adv-check__box"
  }, /*#__PURE__*/React.createElement("i", null)), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/ColorSwatches.jsx
try { (() => {
function ColorSwatches({
  label,
  colors = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "adv-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "adv-caps"
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      padding: '2px'
    },
    role: "radiogroup"
  }, colors.map(c => /*#__PURE__*/React.createElement("button", {
    key: c,
    type: "button",
    role: "radio",
    "aria-checked": c === value,
    "aria-label": c,
    title: c,
    className: 'adv-swatch' + (c === value ? ' is-selected' : ''),
    style: {
      background: c
    },
    onClick: () => onChange && onChange(c)
  }))));
}
Object.assign(__ds_scope, { ColorSwatches });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/ColorSwatches.jsx", error: String((e && e.message) || e) }); }

// components/forms/FrameSelector.jsx
try { (() => {
function FrameSelector({
  label,
  frames = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "adv-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "adv-caps"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "adv-frames",
    role: "listbox"
  }, frames.map(f => {
    const on = f.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: f.id,
      type: "button",
      role: "option",
      "aria-selected": on,
      className: 'adv-frames__opt' + (on ? ' is-selected' : ''),
      onClick: () => onChange && onChange(f.id)
    }, /*#__PURE__*/React.createElement("span", {
      className: "adv-frames__dot"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, f.name), f.meta && /*#__PURE__*/React.createElement("span", {
      className: "adv-mono",
      style: {
        fontSize: 10.5,
        color: 'var(--text-faint)',
        whiteSpace: 'nowrap'
      }
    }, f.meta));
  })));
}
Object.assign(__ds_scope, { FrameSelector });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FrameSelector.jsx", error: String((e && e.message) || e) }); }

// components/forms/SegmentedControl.jsx
try { (() => {
function SegmentedControl({
  label,
  options = [],
  value,
  onChange,
  style
}) {
  const group = /*#__PURE__*/React.createElement("div", {
    className: "adv-seg",
    role: "radiogroup"
  }, options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    const on = v === value;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      role: "radio",
      "aria-checked": on,
      className: 'adv-seg__opt' + (on ? ' is-selected' : ''),
      onClick: () => onChange && onChange(v)
    }, l);
  }));
  if (!label) return /*#__PURE__*/React.createElement("div", {
    style: style
  }, group);
  return /*#__PURE__*/React.createElement("div", {
    className: "adv-field",
    style: style
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-caps"
  }, label), group);
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  options = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "adv-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "adv-caps"
  }, label), /*#__PURE__*/React.createElement("select", {
    className: "adv-input",
    value: value,
    onChange: e => onChange && onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Slider.jsx
try { (() => {
function Slider({
  label,
  min = 0,
  max = 100,
  step = 1,
  value = 0,
  onChange,
  unit = '',
  style
}) {
  const fill = (value - min) / (max - min) * 100;
  return /*#__PURE__*/React.createElement("label", {
    className: "adv-field",
    style: style
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      gap: 8
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "adv-caps"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "adv-mono",
    style: {
      color: 'var(--text-primary)'
    }
  }, value, unit)), /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "adv-range",
    min: min,
    max: max,
    step: step,
    value: value,
    style: {
      '--fill': fill + '%'
    },
    onChange: e => onChange && onChange(Number(e.target.value))
  }));
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Slider.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked = false,
  onChange,
  disabled,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: 'adv-check' + (checked ? ' is-on' : '') + (disabled ? ' is-disabled' : ''),
    style: style
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    role: "switch",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "adv-switch__track"
  }), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function TextField({
  label,
  value,
  onChange,
  placeholder,
  hint,
  multiline = false,
  rows = 3,
  maxLength,
  style
}) {
  const Tag = multiline ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement("label", {
    className: "adv-field",
    style: style
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 8
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "adv-caps"
  }, label), maxLength != null && /*#__PURE__*/React.createElement("span", {
    className: "adv-mono",
    style: {
      fontSize: 10.5,
      color: 'var(--text-faint)'
    }
  }, (value || '').length, "/", maxLength)), /*#__PURE__*/React.createElement(Tag, {
    className: "adv-input",
    value: value,
    placeholder: placeholder,
    rows: multiline ? rows : undefined,
    maxLength: maxLength,
    onChange: e => onChange && onChange(e.target.value)
  }), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-faint)'
    }
  }, hint));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function NavBar({
  brand,
  items = [],
  value,
  onChange,
  right,
  compact = false,
  maxWidth = 600,
  style
}) {
  const h = compact ? 40 : 'var(--nav-h)';
  const shell = compact ? {
    maxWidth,
    width: '100%',
    boxSizing: 'border-box',
    padding: '0 14px',
    gap: 20,
    background: 'var(--surface-panel)',
    border: '1px solid var(--border-subtle)',
    borderRadius: 'var(--radius-panel)',
    boxShadow: 'var(--shadow-panel), var(--inset-frost)',
    backdropFilter: 'blur(var(--blur-frost))',
    WebkitBackdropFilter: 'blur(var(--blur-frost))'
  } : {
    padding: '0 var(--page-gutter)',
    gap: 28,
    background: 'linear-gradient(180deg, rgba(13,17,22,.72), rgba(13,17,22,.38))',
    borderBottom: '1px solid var(--border-subtle)'
  };
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'relative',
      zIndex: 5,
      height: h,
      display: 'flex',
      alignItems: 'center',
      overflow: 'hidden',
      ...shell,
      ...style
    }
  }, brand ?? /*#__PURE__*/React.createElement(__ds_scope.Wordmark, {
    size: compact ? 17 : 19
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: compact ? 'center' : 'flex-start',
      gap: compact ? 18 : 22,
      flex: 1,
      minWidth: 0,
      height: '100%',
      overflow: 'hidden'
    }
  }, items.map(it => {
    const v = typeof it === 'string' ? it : it.value;
    const l = typeof it === 'string' ? it : it.label;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      className: 'adv-nav__link' + (v === value ? ' is-selected' : ''),
      style: compact ? {
        height: '100%',
        fontSize: 'var(--fs-xs)'
      } : undefined,
      "aria-current": v === value ? 'page' : undefined,
      onClick: () => onChange && onChange(v)
    }, l);
  })), right && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, right));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "adv-tabs",
    role: "tablist",
    style: style
  }, items.map(it => {
    const v = typeof it === 'string' ? it : it.value;
    const l = typeof it === 'string' ? it : it.label;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      role: "tab",
      "aria-selected": v === value,
      className: 'adv-tabs__tab' + (v === value ? ' is-selected' : ''),
      onClick: () => onChange && onChange(v)
    }, l);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Panel.jsx
try { (() => {
function Panel({
  title,
  actions,
  tone = 'default',
  accent = false,
  delay = 0,
  padding = 'var(--panel-pad)',
  children,
  style,
  bodyStyle
}) {
  const bg = tone === 'strong' ? 'var(--surface-panel-strong)' : tone === 'clear' ? 'var(--surface-panel-clear)' : 'var(--surface-panel)';
  return /*#__PURE__*/React.createElement("section", {
    className: 'adv-frost adv-panel' + (accent ? ' adv-panel--accent' : ''),
    style: {
      backgroundColor: bg,
      borderRadius: 'var(--radius-panel)',
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0,
      animationDelay: delay ? delay + 'ms' : undefined,
      ...style
    }
  }, (title || actions) && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 12,
      minHeight: 40,
      padding: '0 var(--space-6)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    className: "adv-caps",
    style: {
      color: 'var(--text-secondary)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      paddingRight: '.2em',
      minWidth: 0
    }
  }, title), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, actions)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      minWidth: 0,
      ...bodyStyle
    }
  }, children));
}
Object.assign(__ds_scope, { Panel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Panel.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/PreviewFrame.jsx
try { (() => {
function PreviewFrame({
  label,
  meta,
  background = 'checker',
  zoom = 1,
  minHeight = 260,
  transitionKey,
  children,
  style
}) {
  const bgs = {
    checker: 'repeating-conic-gradient(var(--preview-checker-a) 0 25%, var(--preview-checker-b) 0 50%) 0 0/16px 16px',
    dark: 'var(--preview-dark)',
    mist: 'var(--preview-mist)',
    scenery: 'transparent'
  };
  return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      minWidth: 0,
      ...style
    }
  }, (label || meta) && /*#__PURE__*/React.createElement("figcaption", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-caps",
    style: {
      whiteSpace: 'nowrap'
    }
  }, label), meta && /*#__PURE__*/React.createElement("span", {
    className: "adv-mono",
    style: {
      fontSize: 10.5,
      color: 'var(--text-faint)',
      whiteSpace: 'nowrap'
    }
  }, meta)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      padding: 10,
      border: '1px solid var(--border-default)',
      background: 'var(--preview-mat)'
    }
  }, ['0 auto auto 0', '0 0 auto auto', 'auto auto 0 0', 'auto 0 0 auto'].map((inset, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      position: 'absolute',
      inset,
      width: 7,
      height: 7,
      borderStyle: 'solid',
      borderColor: 'var(--preview-tick)',
      borderWidth: ['1px 0 0 1px', '1px 1px 0 0', '0 0 1px 1px', '0 1px 1px 0'][i],
      margin: -1
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "adv-pixel",
    style: {
      background: bgs[background] || background,
      minHeight,
      transition: 'background var(--dur-slow) var(--ease-hush)',
      display: 'flex',
      overflow: 'auto',
      imageRendering: 'pixelated'
    }
  }, /*#__PURE__*/React.createElement("div", {
    key: transitionKey,
    className: transitionKey != null ? 'adv-preview-in' : undefined,
    style: {
      margin: 'auto',
      zoom: zoom,
      imageRendering: 'pixelated',
      flex: 'none'
    }
  }, children))));
}
Object.assign(__ds_scope, { PreviewFrame });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/PreviewFrame.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/SparkleBanner.jsx
try { (() => {
function SparkleBanner({
  height = 96,
  delay = 0,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "adv-frost adv-sparkle-banner",
    "aria-hidden": children ? undefined : 'true',
    style: {
      height,
      animationDelay: delay ? delay + 'ms' : undefined,
      display: 'grid',
      placeItems: 'center',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { SparkleBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/SparkleBanner.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Tag.jsx
try { (() => {
function Tag({
  children,
  selected = false,
  onClick,
  count,
  style
}) {
  const cls = 'adv-tag' + (selected ? ' is-selected' : '');
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, children, count != null && /*#__PURE__*/React.createElement("span", {
    className: "adv-mono",
    style: {
      fontSize: 10,
      color: 'var(--text-faint)'
    }
  }, count));
  return onClick ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: cls,
    "aria-pressed": selected,
    onClick: onClick,
    style: style
  }, inner) : /*#__PURE__*/React.createElement("span", {
    className: cls,
    style: style
  }, inner);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Tag.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/EditorScreen.jsx
try { (() => {
const {
  Panel,
  Tabs,
  FrameSelector,
  TextField,
  Select,
  Slider,
  SegmentedControl,
  ColorSwatches,
  Checkbox,
  Switch,
  PreviewFrame,
  Button,
  IconButton
} = window.AteliDoValeDesignSystem_a6a127;
const SparkleBanner = window.AteliDoValeDesignSystem_a6a127.SparkleBanner || (() => null);
const SR = window.ScrollRenderer;
const FRAME_LIST = Object.entries(SR.STYLES).map(([id, s]) => ({
  id,
  name: s.name,
  meta: s.font
}));
const defaultsFor = id => {
  const s = SR.STYLES[id];
  return {
    size: s.size,
    align: s.align,
    color: s.color,
    shadow: s.shadow,
    shadowOn: s.shaded
  };
};
function loadSaved() {
  try {
    return JSON.parse(localStorage.getItem('adv-kit-editor'));
  } catch {
    return null;
  }
}
function EditorScreen({
  notify
}) {
  const saved = loadSaved();
  const [o, setO] = React.useState(saved || {
    style: 'standard',
    text: 'Winter Hearth',
    format: 'natural',
    width: 800,
    transparent: true,
    ...defaultsFor('standard')
  });
  const [view, setView] = React.useState('fit');
  const [bg, setBg] = React.useState('checker');
  const [ready, setReady] = React.useState(false);
  const [dims, setDims] = React.useState(null);
  const [boxW, setBoxW] = React.useState(600);
  const canvasRef = React.useRef(null),
    boxRef = React.useRef(null);
  const set = p => setO(v => ({
    ...v,
    ...p
  }));
  const chooseStyle = id => set({
    style: id,
    ...defaultsFor(id)
  });
  React.useEffect(() => {
    SR.ready.then(() => setReady(true)).catch(() => notify('Couldn’t load assets. Reload the page.', 'error'));
  }, []);
  React.useEffect(() => {
    if (!ready || !canvasRef.current) return;
    setDims(SR.render(canvasRef.current, o));
    localStorage.setItem('adv-kit-editor', JSON.stringify(o));
  }, [o, ready]);
  React.useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => setBoxW(e.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const fitW = dims ? Math.min(dims.width, Math.max(80, boxW - 24)) : undefined;
  const zoom = view === 'fit' ? 1 : Number(view);
  const exportPng = async () => {
    const b = await SpriteLib.toBlob(canvasRef.current);
    SpriteLib.download(b, 'glint-' + o.style + '.png');
    notify('PNG saved', 'ok');
  };
  const copyPng = async () => {
    try {
      const b = await SpriteLib.toBlob(canvasRef.current);
      await navigator.clipboard.write([new ClipboardItem({
        'image/png': b
      })]);
      notify('Copied to clipboard');
    } catch {
      notify('Copy blocked by the browser. Use Export PNG.', 'error');
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "kit-stack"
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Preview",
    tone: "strong",
    accent: true,
    actions: /*#__PURE__*/React.createElement("span", {
      className: "adv-mono",
      style: {
        color: 'var(--text-faint)'
      }
    }, dims ? dims.width + '×' + dims.height : '')
  }, /*#__PURE__*/React.createElement("div", {
    ref: boxRef,
    style: {
      minWidth: 0,
      width: '100%',
      maxWidth: 340,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(PreviewFrame, {
    background: bg,
    minHeight: 260,
    zoom: zoom,
    transitionKey: o.style + o.format
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    className: "adv-pixel",
    style: {
      display: 'block',
      imageRendering: 'pixelated',
      width: view === 'fit' ? fitW : undefined
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    options: [{
      value: 'fit',
      label: 'Fit'
    }, {
      value: '1',
      label: '1×'
    }, {
      value: '2',
      label: '2×'
    }, {
      value: '3',
      label: '3×'
    }],
    value: view,
    onChange: setView
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    icon: "copy",
    onClick: copyPng,
    disabled: !ready
  }, "Copy"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "download",
    onClick: exportPng,
    disabled: !ready
  }, "Export PNG"))), /*#__PURE__*/React.createElement(SparkleBanner, {
    delay: 60
  }), /*#__PURE__*/React.createElement(Panel, {
    title: "Frame",
    delay: 100,
    actions: /*#__PURE__*/React.createElement(IconButton, {
      icon: "rotate-ccw",
      label: "Reset style",
      variant: "ghost",
      size: "sm",
      onClick: () => chooseStyle(o.style)
    })
  }, /*#__PURE__*/React.createElement(FrameSelector, {
    frames: FRAME_LIST,
    value: o.style,
    onChange: chooseStyle
  }), /*#__PURE__*/React.createElement(SegmentedControl, {
    label: "Preview ground",
    options: [{
      value: 'checker',
      label: 'Checker'
    }, {
      value: 'dark',
      label: 'Dark'
    }, {
      value: 'mist',
      label: 'Mist'
    }],
    value: bg,
    onChange: setBg
  })), /*#__PURE__*/React.createElement(Panel, {
    title: "Text",
    delay: 200
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Text",
    multiline: true,
    rows: 3,
    value: o.text,
    onChange: v => set({
      text: v
    }),
    hint: "One frame per line"
  }), /*#__PURE__*/React.createElement("div", {
    className: "kit-pair"
  }, /*#__PURE__*/React.createElement(Slider, {
    label: "Size",
    min: 10,
    max: 80,
    value: o.size,
    onChange: v => set({
      size: v
    }),
    unit: "px"
  }), /*#__PURE__*/React.createElement(SegmentedControl, {
    label: "Align",
    options: [{
      value: 'left',
      label: 'Left'
    }, {
      value: 'center',
      label: 'Center'
    }, {
      value: 'right',
      label: 'Right'
    }],
    value: o.align,
    onChange: v => set({
      align: v
    })
  })), /*#__PURE__*/React.createElement(ColorSwatches, {
    label: "Text colour",
    colors: ['#611a0d', '#ce5252', '#221122', '#ffffff', '#ffd4b3', '#2b3f6b'],
    value: o.color,
    onChange: v => set({
      color: v
    })
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Text shadow",
    checked: o.shadowOn,
    onChange: v => set({
      shadowOn: v
    })
  }), o.shadowOn && /*#__PURE__*/React.createElement(ColorSwatches, {
    label: "Shadow colour",
    colors: ['#ce9c5f', '#934848', '#666666', '#5b191e', '#000000'],
    value: o.shadow,
    onChange: v => set({
      shadow: v
    })
  })), /*#__PURE__*/React.createElement(Panel, {
    title: "Export",
    delay: 300
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Format",
    options: [{
      value: 'natural',
      label: 'Natural size'
    }, {
      value: 'nexus',
      label: 'Nexus banner · 1400×400'
    }, {
      value: 'custom',
      label: 'Custom width'
    }],
    value: o.format,
    onChange: v => set({
      format: v
    })
  }), o.format === 'custom' && /*#__PURE__*/React.createElement(Slider, {
    label: "Width",
    min: 200,
    max: 2400,
    step: 10,
    value: o.width,
    onChange: v => set({
      width: v
    }),
    unit: "px"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Transparent background",
    checked: o.transparent,
    onChange: v => set({
      transparent: v
    })
  })));
}
window.EditorScreen = EditorScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/EditorScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/GalleryScreen.jsx
try { (() => {
const {
  Panel: GPanel,
  TextField: GText,
  EmojiTile
} = window.AteliDoValeDesignSystem_a6a127;
const GBanner = window.AteliDoValeDesignSystem_a6a127.SparkleBanner || (() => null);
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const SECTIONS = [{
  source: 'EmoteMenu',
  label: 'Emotes',
  zoom: 3,
  size: 48,
  kind: 'Emote',
  links: 'emotes'
}, {
  source: 'emojis',
  label: 'Emojis',
  zoom: 4,
  size: 36,
  kind: 'Emoji',
  links: 'emojis'
}];
// Extra animated emojis shipped as GIFs, inserted after emoji #100 to match the Imgur album numbering.
const EXTRA_EMOJIS = [1, 2].map(n => ({
  key: 'heart' + n,
  gif: '../../assets/sprites/heart-animated-' + n + '.gif?v=2',
  animated: true
}));
const withExtras = (source, list) => source === 'emojis' ? [...list.slice(0, 100), ...EXTRA_EMOJIS, ...list.slice(100)] : list;
function GalleryDivider({
  label,
  count
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-caps",
    style: {
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--grad-hairline)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "adv-mono",
    style: {
      color: 'var(--text-faint)'
    }
  }, count));
}
function GalleryScreen({
  notify
}) {
  const [ready, setReady] = React.useState(false);
  const [q, setQ] = React.useState('');
  const [frame, setFrame] = React.useState(0);
  const [copied, setCopied] = React.useState(null);
  React.useEffect(() => {
    SpriteLib.ready.then(() => setReady(true)).catch(() => notify('Couldn’t load the collection.', 'error'));
  }, []);
  React.useEffect(() => {
    if (reduceMotion) return;
    const t = setInterval(() => setFrame(f => 1 - f), 400);
    return () => clearInterval(t);
  }, []);
  const data = React.useMemo(() => ready ? SECTIONS.map(sec => ({
    ...sec,
    sprites: withExtras(sec.source, SpriteLib.slice(sec.source).map(s => ({
      ...s,
      key: sec.source + s.id,
      urls: (s.animated ? [0, 1] : [0]).map(f => SpriteLib.canvasFor(s, sec.zoom, f).toDataURL())
    }))).map((s, n) => ({
      ...s,
      num: n + 1
    }))
  })) : [], [ready]);
  // Click copies the sprite's image link (lib/sprite-links.js, same numbering). Falls back to the PNG if no link is set.
  const copyLink = async (s, sec) => {
    const url = ((window.SPRITE_LINKS || {})[sec.links] || [])[s.num - 1];
    try {
      if (url) {
        await navigator.clipboard.writeText(url);
        setCopied(s.key);
        notify(sec.kind + ' ' + s.num + ' link copied');
        return;
      }
      if (s.gif) {
        notify('No link for this one yet.', 'error');
        return;
      }
      const b = await SpriteLib.toBlob(SpriteLib.canvasFor(s, 4, 0));
      await navigator.clipboard.write([new ClipboardItem({
        'image/png': b
      })]);
      setCopied(s.key);
      notify(sec.kind + ' ' + s.num + ' copied as image');
    } catch {
      notify('Copy blocked by the browser.', 'error');
    }
  };
  const match = s => !q.trim() || String(s.num).includes(q.trim());
  return /*#__PURE__*/React.createElement("div", {
    className: "kit-stack"
  }, /*#__PURE__*/React.createElement(GPanel, {
    title: "Emotes & Emojis",
    delay: 120,
    actions: /*#__PURE__*/React.createElement("span", {
      className: "adv-mono",
      style: {
        color: 'var(--text-faint)'
      }
    }, "Click to copy")
  }, /*#__PURE__*/React.createElement(GText, {
    placeholder: "Search by number",
    value: q,
    onChange: setQ
  }), data.map(sec => {
    const list = sec.sprites.filter(match);
    return /*#__PURE__*/React.createElement("section", {
      key: sec.source,
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(GalleryDivider, {
      label: sec.label,
      count: list.length
    }), list.length ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill,minmax(68px,1fr))',
        gap: 6
      }
    }, list.map(s => /*#__PURE__*/React.createElement(EmojiTile, {
      key: s.key,
      name: '#' + String(s.num).padStart(3, '0'),
      code: sec.kind + ' ' + s.num + ' · click to copy',
      src: s.gif || s.urls[s.animated ? frame : 0],
      size: sec.size,
      animated: s.animated,
      selected: copied === s.key,
      onClick: () => copyLink(s, sec)
    }))) : /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        font: 'var(--type-body-sm)',
        color: 'var(--text-muted)'
      }
    }, "No ", sec.label.toLowerCase(), " match \u201C", q, "\u201D."));
  })));
}
window.GalleryScreen = GalleryScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/GalleryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/lib/gif.js
try { (() => {
// Lossless palette GIF for small pixel-art animations. Clear codes keep LZW
// code widths fixed, trading a little file size for a compact, predictable encoder.
function encodeEmoteGif(frames, width, height, delay = 30) {
  const palette = [[0, 0, 0]],
    colors = new Map();
  for (const rgba of frames) for (let i = 0; i < rgba.length; i += 4) {
    if (rgba[i + 3] < 128) continue;
    const key = rgba[i] << 16 | rgba[i + 1] << 8 | rgba[i + 2];
    if (!colors.has(key)) {
      if (palette.length >= 256) throw new Error('A imagem tem mais de 255 cores.');
      colors.set(key, palette.length);
      palette.push([rgba[i], rgba[i + 1], rgba[i + 2]]);
    }
  }
  const bytes = [],
    byte = v => bytes.push(v & 255),
    word = v => {
      byte(v);
      byte(v >> 8);
    },
    ascii = s => {
      for (const c of s) byte(c.charCodeAt(0));
    };
  ascii('GIF89a');
  word(width);
  word(height);
  byte(0xf7);
  byte(0);
  byte(0);
  for (let i = 0; i < 256; i++) for (const v of palette[i] || [0, 0, 0]) byte(v);
  byte(0x21);
  byte(0xff);
  byte(11);
  ascii('NETSCAPE2.0');
  byte(3);
  byte(1);
  word(0);
  byte(0);
  for (const rgba of frames) {
    byte(0x21);
    byte(0xf9);
    byte(4);
    byte(9);
    word(delay);
    byte(0);
    byte(0);
    byte(0x2c);
    word(0);
    word(0);
    word(width);
    word(height);
    byte(0);
    byte(8);
    const packed = [];
    let buffer = 0,
      bits = 0;
    const code = v => {
      buffer |= v << bits;
      bits += 9;
      while (bits >= 8) {
        packed.push(buffer & 255);
        buffer >>>= 8;
        bits -= 8;
      }
    };
    for (let i = 0; i < rgba.length; i += 4) {
      code(256);
      code(rgba[i + 3] < 128 ? 0 : colors.get(rgba[i] << 16 | rgba[i + 1] << 8 | rgba[i + 2]));
    }
    code(257);
    if (bits) packed.push(buffer & 255);
    for (let i = 0; i < packed.length; i += 255) {
      const block = packed.slice(i, i + 255);
      byte(block.length);
      bytes.push(...block);
    }
    byte(0);
  }
  byte(0x3b);
  return new Uint8Array(bytes);
}
if (typeof module !== 'undefined') module.exports = {
  encodeEmoteGif
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/lib/gif.js", error: String((e && e.message) || e) }); }

// ui_kits/web/lib/scroll-renderer.js
try { (() => {
// Adapted from implementation-reference/renderer.js (Scrollish frame dimensions by kdau).
// Draws ONLY the asset onto the canvas — no UI effects ever reach the export.
(function () {
  const ASSET_ROOT = (window.ADV_ASSET_ROOT || '../../assets/') + 'scrollish/';
  const STYLES = {
    standard: {
      name: 'Parchment',
      height: 36,
      left: 24,
      right: 24,
      font: 'Stardew Valley',
      size: 26,
      align: 'center',
      color: '#611a0d',
      shadow: '#ce9c5f',
      shaded: true
    },
    menu: {
      name: 'Main Menu',
      height: 39,
      left: 15,
      right: 17,
      font: 'Stardew Valley',
      size: 26,
      align: 'center',
      color: '#ce5252',
      shadow: '#934848',
      shaded: false,
      long: true
    },
    text: {
      name: 'Dialogue Box',
      height: 24,
      left: 10,
      right: 8,
      font: 'Cave Story',
      size: 20,
      align: 'left',
      color: '#221122',
      shadow: '#ce9c5f',
      shaded: false
    },
    chat: {
      name: 'Chat',
      height: 28,
      left: 10,
      right: 10,
      font: 'Cave Story',
      size: 20,
      align: 'left',
      color: '#ffffff',
      shadow: '#666666',
      shaded: false
    },
    solarion: {
      name: 'Solarion',
      height: 40,
      left: 15,
      right: 15,
      font: 'Cave Story',
      size: 25,
      align: 'center',
      color: '#ffd4b3',
      shadow: '#5b191e',
      shaded: true
    }
  };
  const assets = {};
  function loadImg(src) {
    return new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = src;
    });
  }
  const ready = Promise.all([...Object.keys(STYLES).flatMap(k => ['left', 'right', 'text'].map(p => loadImg(ASSET_ROOT + k + '/' + p + '.png').then(img => {
    (assets[k] ??= {})[p] = img;
  }))), document.fonts.load('26px "Stardew Valley"'), document.fonts.load('20px "Cave Story"')]);
  function render(canvas, o) {
    const s = STYLES[o.style] || STYLES.standard,
      a = assets[o.style] || assets.standard;
    if (!a || !a.text) return null;
    const ctx = canvas.getContext('2d');
    const size = +o.size || s.size,
      ratio = size / s.size,
      lines = (o.text || 'Your title here').split('\n');
    ctx.font = s.size + 'px "' + s.font + '"';
    const textWidth = Math.ceil(Math.max(...lines.map(t => ctx.measureText(t).width))) + 2;
    const naturalWidth = Math.max(s.left + s.right + 12, textWidth + s.left + s.right),
      naturalHeight = lines.length * s.height;
    let scale = ratio,
      width = Math.ceil(naturalWidth * scale),
      height = Math.ceil(naturalHeight * scale);
    if (o.format === 'nexus') {
      width = 1400;
      height = 400;
      scale = Math.min(ratio * 2, (width - 20) / naturalWidth, (height - 20) / naturalHeight);
    } else if (o.format === 'custom') {
      width = Math.max(200, Math.min(2400, +o.width || 800));
      height = Math.ceil(naturalHeight * scale);
      scale = Math.min(scale, width / naturalWidth);
    }
    if (height > 12000) {
      scale *= 12000 / height;
      height = 12000;
    }
    canvas.width = width;
    canvas.height = height;
    ctx.imageSmoothingEnabled = false;
    if (!o.transparent) {
      ctx.fillStyle = '#edf0df';
      ctx.fillRect(0, 0, width, height);
    }
    const logicalWidth = o.format === 'custom' ? width / scale : naturalWidth;
    ctx.save();
    ctx.translate(Math.round((width - logicalWidth * scale) / 2), Math.round((height - naturalHeight * scale) / 2));
    ctx.scale(scale, scale);
    const tile = (img, x, y, w, h) => {
      ctx.save();
      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.clip();
      for (let yy = y; yy < y + h; yy += img.height) for (let xx = x; xx < x + w; xx += img.width) ctx.drawImage(img, xx, yy);
      ctx.restore();
    };
    const align = o.align || s.align;
    lines.forEach((line, i) => {
      const y = i * s.height;
      if (s.long) tile(a.text, 0, y, logicalWidth, s.height);else tile(a.text, s.left, y, logicalWidth - s.left - s.right, s.height);
      ctx.drawImage(a.left, 0, y);
      ctx.drawImage(a.right, logicalWidth - a.right.width, y);
      ctx.font = s.size + 'px "' + s.font + '"';
      ctx.textBaseline = 'alphabetic';
      ctx.textAlign = align;
      const x = align === 'left' ? s.left + 1 : align === 'right' ? logicalWidth - s.right - 1 : (s.left + logicalWidth - s.right) / 2;
      const baseline = y + (s.height - s.size) / 2 + s.size * .8;
      if (o.shadowOn) {
        ctx.fillStyle = o.shadow;
        ctx.fillText(line, x - 1, baseline + 1);
      }
      ctx.fillStyle = o.color;
      ctx.fillText(line, x, baseline);
    });
    ctx.restore();
    return {
      width,
      height
    };
  }
  window.ScrollRenderer = {
    STYLES,
    ready,
    render
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/lib/scroll-renderer.js", error: String((e && e.message) || e) }); }

// ui_kits/web/lib/sprite-links.js
try { (() => {
// Direct image links, in gallery order (#001 = index 0).
// Emotes: https://imgur.com/gallery/emotes-bWfmGTX — 001–015 static, 016–025 animated GIFs.
// Emojis: https://imgur.com/a/T3yjPa8 — 198 items; #101–102 are the animated hearts (assets/sprites/heart-animated-*.gif).
window.SPRITE_LINKS = {
  emotes: ["https://i.imgur.com/mNHDBHF.png", "https://i.imgur.com/tZeaTk3.png", "https://i.imgur.com/NUIT6GS.png", "https://i.imgur.com/XKbNLmX.png", "https://i.imgur.com/Xcbmgtv.png", "https://i.imgur.com/UrYK1CS.png", "https://i.imgur.com/dZYPCg5.png", "https://i.imgur.com/P7h5Iu9.png", "https://i.imgur.com/Ff3kdDw.png", "https://i.imgur.com/g4KqROr.png", "https://i.imgur.com/uRwRrEI.png", "https://i.imgur.com/8Uopgrd.png", "https://i.imgur.com/no8Hedl.png", "https://i.imgur.com/x825YP6.png", "https://i.imgur.com/QFteKUx.png", "https://i.imgur.com/LvvS4rd.gif", "https://i.imgur.com/VUiZiYt.gif", "https://i.imgur.com/L1IdCCf.gif", "https://i.imgur.com/6uwrjYt.gif", "https://i.imgur.com/esKcB3j.gif", "https://i.imgur.com/OXA7FNK.gif", "https://i.imgur.com/VP8CJQx.gif", "https://i.imgur.com/ARcNlpO.gif", "https://i.imgur.com/ypKxU93.gif", "https://i.imgur.com/447VOPQ.gif"],
  emojis: ["https://i.imgur.com/tOMJJwF.png", "https://i.imgur.com/07fLfat.png", "https://i.imgur.com/6hXg7Ly.png", "https://i.imgur.com/2AjbcWc.png", "https://i.imgur.com/yzF2Mc8.png", "https://i.imgur.com/SHKtT2m.png", "https://i.imgur.com/vcEFPr9.png", "https://i.imgur.com/Fkc4W88.png", "https://i.imgur.com/yLcuIWh.png", "https://i.imgur.com/3KF9vTv.png", "https://i.imgur.com/NGGOoym.png", "https://i.imgur.com/kXMlK8P.png", "https://i.imgur.com/4vqso8j.png", "https://i.imgur.com/wnzeF53.png", "https://i.imgur.com/Sietpah.png", "https://i.imgur.com/k9Pojpc.png", "https://i.imgur.com/yO2xB8N.png", "https://i.imgur.com/Rfljtyd.png", "https://i.imgur.com/i5YmRPO.png", "https://i.imgur.com/hkOBajq.png", "https://i.imgur.com/3qIwiu4.png", "https://i.imgur.com/NXhoEdS.png", "https://i.imgur.com/gUDGJV9.png", "https://i.imgur.com/0AEns9h.png", "https://i.imgur.com/wNQqotr.png", "https://i.imgur.com/Y60AeaB.png", "https://i.imgur.com/Ex7nODa.png", "https://i.imgur.com/ZbDnziA.png", "https://i.imgur.com/k4nAMjm.png", "https://i.imgur.com/npXg8W4.png", "https://i.imgur.com/aNwZ7m1.png", "https://i.imgur.com/ObrBA1J.png", "https://i.imgur.com/BZGVj1K.png", "https://i.imgur.com/i5KwN4v.png", "https://i.imgur.com/MFW02eT.png", "https://i.imgur.com/CUhzN2h.png", "https://i.imgur.com/A0W3EYe.png", "https://i.imgur.com/JhcNd1E.png", "https://i.imgur.com/4If1FGA.png", "https://i.imgur.com/gPPscb4.png", "https://i.imgur.com/1aMOhgU.png", "https://i.imgur.com/SDCgNFo.png", "https://i.imgur.com/ImgBwaj.png", "https://i.imgur.com/tJwJkLq.png", "https://i.imgur.com/stfyYqW.png", "https://i.imgur.com/VrrQWHb.png", "https://i.imgur.com/63u6ID8.png", "https://i.imgur.com/urnnDtr.png", "https://i.imgur.com/4hTJacz.png", "https://i.imgur.com/gFXL1xc.png", "https://i.imgur.com/oS40MuS.png", "https://i.imgur.com/oOfA7iN.png", "https://i.imgur.com/boXSWzf.png", "https://i.imgur.com/Iry6ILz.png", "https://i.imgur.com/46ePxVT.png", "https://i.imgur.com/GdA0mnQ.png", "https://i.imgur.com/eyoGh0Y.png", "https://i.imgur.com/KtiHCd2.png", "https://i.imgur.com/rNYeC6l.png", "https://i.imgur.com/p6nmix5.png", "https://i.imgur.com/CwZLgU8.png", "https://i.imgur.com/Z5LT87f.png", "https://i.imgur.com/X4Xrg2y.png", "https://i.imgur.com/faxtLun.png", "https://i.imgur.com/NBl0t3L.png", "https://i.imgur.com/sTECCe4.png", "https://i.imgur.com/JIaBNJc.png", "https://i.imgur.com/PvHeo72.png", "https://i.imgur.com/4Y6d5AR.png", "https://i.imgur.com/Tx2V7Kg.png", "https://i.imgur.com/6DKrYYB.png", "https://i.imgur.com/tk6RqIv.png", "https://i.imgur.com/WItzrEI.png", "https://i.imgur.com/m225H2J.png", "https://i.imgur.com/fHyRY9J.png", "https://i.imgur.com/d5sZpo3.png", "https://i.imgur.com/prqLPNv.png", "https://i.imgur.com/ViL9Gdg.png", "https://i.imgur.com/5YBulmD.png", "https://i.imgur.com/5y2N0U4.png", "https://i.imgur.com/Yo6mcug.png", "https://i.imgur.com/K3UOcAk.png", "https://i.imgur.com/7YXQSVy.png", "https://i.imgur.com/ZRTJU6H.png", "https://i.imgur.com/UsS7Ma7.png", "https://i.imgur.com/xPb9FM7.png", "https://i.imgur.com/iTbpJmY.png", "https://i.imgur.com/3kcId0E.png", "https://i.imgur.com/7s3eCus.png", "https://i.imgur.com/494q6To.png", "https://i.imgur.com/XCaBdRJ.png", "https://i.imgur.com/m3fhXeS.png", "https://i.imgur.com/fNPKGwU.png", "https://i.imgur.com/XIeaNvk.png", "https://i.imgur.com/y7woivI.png", "https://i.imgur.com/6aRDhpc.png", "https://i.imgur.com/em5imDd.png", "https://i.imgur.com/rdDwa0y.png", "https://i.imgur.com/4eMdFG7.png", "https://i.imgur.com/KVgNadD.png", "https://i.imgur.com/OQEYBDm.gif", "https://i.imgur.com/5Xltfr3.gif", "https://i.imgur.com/G0VHpho.png", "https://i.imgur.com/af9OVSz.png", "https://i.imgur.com/efdDf65.png", "https://i.imgur.com/sw8tI3n.png", "https://i.imgur.com/YLDuHP6.png", "https://i.imgur.com/PTVpScL.png", "https://i.imgur.com/MKWgTo3.png", "https://i.imgur.com/in1zqDn.png", "https://i.imgur.com/DL9QiDJ.png", "https://i.imgur.com/jPsQSS2.png", "https://i.imgur.com/jhYYN4I.png", "https://i.imgur.com/rCFDKrr.png", "https://i.imgur.com/1DEigCr.png", "https://i.imgur.com/Y1eyUcj.png", "https://i.imgur.com/XVhZsIC.png", "https://i.imgur.com/BO8bY0j.png", "https://i.imgur.com/UFPSCMz.png", "https://i.imgur.com/y8tYHld.png", "https://i.imgur.com/vUzrWhT.png", "https://i.imgur.com/y1nCS0P.png", "https://i.imgur.com/dWLwUAm.png", "https://i.imgur.com/yOU64jf.png", "https://i.imgur.com/qIdfyUR.png", "https://i.imgur.com/GDZOuvz.png", "https://i.imgur.com/jM9kXFy.png", "https://i.imgur.com/5Osv7OY.png", "https://i.imgur.com/co1ok2Q.png", "https://i.imgur.com/dyhLspn.png", "https://i.imgur.com/gghnf22.png", "https://i.imgur.com/dAXSji5.png", "https://i.imgur.com/QlDBZb1.png", "https://i.imgur.com/MW6CQXR.png", "https://i.imgur.com/tSjH0vi.png", "https://i.imgur.com/hGWd5No.png", "https://i.imgur.com/QU8Vzig.png", "https://i.imgur.com/sVoRKOE.png", "https://i.imgur.com/LsfeqDU.png", "https://i.imgur.com/5rE12Cw.png", "https://i.imgur.com/LpP4O9p.png", "https://i.imgur.com/xtOW4Pp.png", "https://i.imgur.com/QMToaKy.png", "https://i.imgur.com/y6VfmgE.png", "https://i.imgur.com/yoM4Zf6.png", "https://i.imgur.com/h2HrM9o.png", "https://i.imgur.com/5OvWpwr.png", "https://i.imgur.com/BtnjK0h.png", "https://i.imgur.com/e9Vmcoo.png", "https://i.imgur.com/WAkchtL.png", "https://i.imgur.com/EfX1ygS.png", "https://i.imgur.com/npHdf89.png", "https://i.imgur.com/DIlPYQ4.png", "https://i.imgur.com/UlV0b77.png", "https://i.imgur.com/UBkqHEy.png", "https://i.imgur.com/0pystmr.png", "https://i.imgur.com/O7q5ub2.png", "https://i.imgur.com/QIjoYT3.png", "https://i.imgur.com/W1S1AKv.png", "https://i.imgur.com/IQTmocx.png", "https://i.imgur.com/T5ysLDV.png", "https://i.imgur.com/5daSVJM.png", "https://i.imgur.com/GVulkNI.png", "https://i.imgur.com/Q5gwUfd.png", "https://i.imgur.com/IPDqI1N.png", "https://i.imgur.com/GxdDMO7.png", "https://i.imgur.com/qTTcmzL.png", "https://i.imgur.com/YvVcDjH.png", "https://i.imgur.com/YMXwzZ0.png", "https://i.imgur.com/wHzuenr.png", "https://i.imgur.com/rLmQJKr.png", "https://i.imgur.com/c0zSrlB.png", "https://i.imgur.com/plRayQn.png", "https://i.imgur.com/Bheeq6I.png", "https://i.imgur.com/Ug8OrRS.png", "https://i.imgur.com/33UrzVL.png", "https://i.imgur.com/g5QJ6Am.png", "https://i.imgur.com/WsBHSVD.png", "https://i.imgur.com/BlSLTqZ.png", "https://i.imgur.com/2kZinv9.png", "https://i.imgur.com/SsdJPBM.png", "https://i.imgur.com/94gy5tr.png", "https://i.imgur.com/4ueJOl7.png", "https://i.imgur.com/BLDCUyi.png", "https://i.imgur.com/GS758KG.png", "https://i.imgur.com/cBY43YD.png", "https://i.imgur.com/YbiFOfv.png", "https://i.imgur.com/htjk15a.png", "https://i.imgur.com/EIo0yoB.png", "https://i.imgur.com/kr7Pf7Y.png", "https://i.imgur.com/z4LzYwr.png", "https://i.imgur.com/gcwFt48.png", "https://i.imgur.com/qiXReGI.png", "https://i.imgur.com/t3wAqMq.png", "https://i.imgur.com/TYbXq8C.png", "https://i.imgur.com/1GLkt32.png", "https://i.imgur.com/PhuFziQ.png", "https://i.imgur.com/USuUO7u.png"]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/lib/sprite-links.js", error: String((e && e.message) || e) }); }

// ui_kits/web/lib/sprites.js
try { (() => {
// Adapted from implementation-reference/gallery.js — slicing, blank-cell filtering, exclusions, animation pairing.
(function () {
  const ROOT = (window.ADV_ASSET_ROOT || '../../assets/') + 'sprites/';
  const images = {};
  const ready = Promise.all(['emojis', 'EmoteMenu', 'emotes-frame-1', 'emotes-frame-2'].map(k => new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => {
      images[k] = i;
      res();
    };
    i.onerror = rej;
    i.src = ROOT + k + '.png';
  })));
  function slice(source) {
    const img = images[source];
    if (!img) return [];
    const cell = source === 'emojis' ? 9 : 16;
    const out = [];
    const scan = document.createElement('canvas');
    scan.width = img.width;
    scan.height = img.height;
    const sc = scan.getContext('2d');
    sc.drawImage(img, 0, 0);
    for (let y = 0; y < img.height; y += cell) for (let x = 0; x < img.width; x += cell) {
      // Lower-left and lower-right groups of EmoteMenu are animation frames; they come from the frame sheets instead.
      if (source === 'EmoteMenu' && y >= 48 && (x < 64 || x >= 80)) continue;
      const w = Math.min(cell, img.width - x),
        h = Math.min(cell, img.height - y),
        px = sc.getImageData(x, y, w, h).data;
      if (!px.some((v, i) => i % 4 === 3 && v > 0)) continue;
      const id = Math.floor(y / cell) * Math.ceil(img.width / cell) + Math.floor(x / cell) + 1;
      if (source === 'emojis' && (id === 148 || id >= 199 && id <= 210)) continue;
      if (source === 'EmoteMenu' && [15, 41, 32, 6, 7, 16].includes(id)) continue;
      out.push({
        x,
        y,
        w,
        h,
        id,
        source
      });
    }
    if (source === 'EmoteMenu') {
      // Final two cells of each frame sheet are empty placeholders.
      for (let i = 0; i < 10; i++) out.push({
        x: i % 4 * 16,
        y: Math.floor(i / 4) * 16,
        w: 16,
        h: 16,
        id: (Math.floor(i / 4) + 3) * 9 + i % 4 + 1,
        animated: true,
        source
      });
      out.sort((a, b) => (a.animated ? 1 : 0) - (b.animated ? 1 : 0) || a.id - b.id); // static first, then animated — matches the Imgur album numbering
    }
    return out;
  }
  function canvasFor(s, zoom = 1, frame = 0) {
    const c = document.createElement('canvas');
    c.width = s.w * zoom;
    c.height = s.h * zoom;
    const x = c.getContext('2d');
    x.imageSmoothingEnabled = false;
    const img = s.animated ? images['emotes-frame-' + (frame + 1)] : images[s.source];
    x.drawImage(img, s.x, s.y, s.w, s.h, 0, 0, c.width, c.height);
    return c;
  }
  function gif(s, zoom, delayMs) {
    const frames = [0, 1].map(f => {
      const c = canvasFor(s, zoom, f);
      return c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    });
    return new Blob([encodeEmoteGif(frames, s.w * zoom, s.h * zoom, Math.round(delayMs / 10))], {
      type: 'image/gif'
    });
  }
  function download(blob, name) {
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(u), 2000);
  }
  const toBlob = c => new Promise(r => c.toBlob(r, 'image/png'));
  window.SpriteLib = {
    ready,
    slice,
    canvasFor,
    gif,
    download,
    toBlob
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/lib/sprites.js", error: String((e && e.message) || e) }); }

__ds_ns.Scenery = __ds_scope.Scenery;

__ds_ns.SnowField = __ds_scope.SnowField;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.EmojiTile = __ds_scope.EmojiTile;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.ColorSwatches = __ds_scope.ColorSwatches;

__ds_ns.FrameSelector = __ds_scope.FrameSelector;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.NavBar = __ds_scope.NavBar;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.PreviewFrame = __ds_scope.PreviewFrame;

__ds_ns.SparkleBanner = __ds_scope.SparkleBanner;

__ds_ns.Tag = __ds_scope.Tag;

})();
