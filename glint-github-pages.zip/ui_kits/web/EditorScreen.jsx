const { Panel, Tabs, FrameSelector, TextField, Select, Slider, SegmentedControl, ColorSwatches, Checkbox, Switch, PreviewFrame, Button, IconButton } = window.AteliDoValeDesignSystem_a6a127;
const SparkleBanner=window.AteliDoValeDesignSystem_a6a127.SparkleBanner||(()=>null);
const SR=window.ScrollRenderer;
const FRAME_LIST=Object.entries(SR.STYLES).map(([id,s])=>({id,name:s.name,meta:s.font}));
const defaultsFor=id=>{const s=SR.STYLES[id];return {size:s.size,align:s.align,color:s.color,shadow:s.shadow,shadowOn:s.shaded}};
function loadSaved(){try{return JSON.parse(localStorage.getItem('adv-kit-editor'))}catch{return null}}
function EditorScreen({notify}){
  const saved=loadSaved();
  const [o,setO]=React.useState(saved||{style:'standard',text:'Winter Hearth',format:'natural',width:800,transparent:true,...defaultsFor('standard')});
  const [view,setView]=React.useState('fit');
  const [bg,setBg]=React.useState('checker');
  const [ready,setReady]=React.useState(false);
  const [dims,setDims]=React.useState(null);
  const [boxW,setBoxW]=React.useState(600);
  const canvasRef=React.useRef(null),boxRef=React.useRef(null);
  const set=p=>setO(v=>({...v,...p}));
  const chooseStyle=id=>set({style:id,...defaultsFor(id)});
  React.useEffect(()=>{SR.ready.then(()=>setReady(true)).catch(()=>notify('Couldn’t load assets. Reload the page.','error'))},[]);
  React.useEffect(()=>{if(!ready||!canvasRef.current)return;setDims(SR.render(canvasRef.current,o));localStorage.setItem('adv-kit-editor',JSON.stringify(o))},[o,ready]);
  React.useEffect(()=>{const el=boxRef.current;if(!el)return;const ro=new ResizeObserver(([e])=>setBoxW(e.contentRect.width));ro.observe(el);return()=>ro.disconnect()},[]);
  const fitW=dims?Math.min(dims.width,Math.max(80,boxW-24)):undefined;
  const zoom=view==='fit'?1:Number(view);
  const exportPng=async()=>{const b=await SpriteLib.toBlob(canvasRef.current);SpriteLib.download(b,'glint-'+o.style+'.png');notify('PNG saved','ok')};
  const copyPng=async()=>{try{const b=await SpriteLib.toBlob(canvasRef.current);await navigator.clipboard.write([new ClipboardItem({'image/png':b})]);notify('Copied to clipboard')}catch{notify('Copy blocked by the browser. Use Export PNG.','error')}};
  return <div className="kit-stack">
    <Panel title="Preview" tone="strong" accent actions={<span className="adv-mono" style={{color:'var(--text-faint)'}}>{dims?dims.width+'×'+dims.height:''}</span>}>
      <div ref={boxRef} style={{minWidth:0,width:'100%',maxWidth:340,margin:'0 auto'}}>
        <PreviewFrame background={bg} minHeight={260} zoom={zoom} transitionKey={o.style+o.format}>
          <canvas ref={canvasRef} className="adv-pixel" style={{display:'block',imageRendering:'pixelated',width:view==='fit'?fitW:undefined}}/>
        </PreviewFrame>
      </div>
      <div style={{display:'flex',flexWrap:'wrap',alignItems:'center',gap:10}}>
        <SegmentedControl options={[{value:'fit',label:'Fit'},{value:'1',label:'1×'},{value:'2',label:'2×'},{value:'3',label:'3×'}]} value={view} onChange={setView}/>
        <span style={{flex:1}}/>
        <Button icon="copy" onClick={copyPng} disabled={!ready}>Copy</Button>
        <Button variant="primary" icon="download" onClick={exportPng} disabled={!ready}>Export PNG</Button>
      </div>
    </Panel>
    <SparkleBanner delay={60}/>
    <Panel title="Frame" delay={100} actions={<IconButton icon="rotate-ccw" label="Reset style" variant="ghost" size="sm" onClick={()=>chooseStyle(o.style)}/>}>
      <FrameSelector frames={FRAME_LIST} value={o.style} onChange={chooseStyle}/>
      <SegmentedControl label="Preview ground" options={[{value:'checker',label:'Checker'},{value:'dark',label:'Dark'},{value:'mist',label:'Mist'}]} value={bg} onChange={setBg}/>
    </Panel>
    <Panel title="Text" delay={200}>
      <TextField label="Text" multiline rows={3} value={o.text} onChange={v=>set({text:v})} hint="One frame per line"/>
      <div className="kit-pair">
        <Slider label="Size" min={10} max={80} value={o.size} onChange={v=>set({size:v})} unit="px"/>
        <SegmentedControl label="Align" options={[{value:'left',label:'Left'},{value:'center',label:'Center'},{value:'right',label:'Right'}]} value={o.align} onChange={v=>set({align:v})}/>
      </div>
      <ColorSwatches label="Text colour" colors={['#611a0d','#ce5252','#221122','#ffffff','#ffd4b3','#2b3f6b']} value={o.color} onChange={v=>set({color:v})}/>
      <Switch label="Text shadow" checked={o.shadowOn} onChange={v=>set({shadowOn:v})}/>
      {o.shadowOn&&<ColorSwatches label="Shadow colour" colors={['#ce9c5f','#934848','#666666','#5b191e','#000000']} value={o.shadow} onChange={v=>set({shadow:v})}/>}
    </Panel>
    <Panel title="Export" delay={300}>
      <Select label="Format" options={[{value:'natural',label:'Natural size'},{value:'nexus',label:'Nexus banner · 1400×400'},{value:'custom',label:'Custom width'}]} value={o.format} onChange={v=>set({format:v})}/>
      {o.format==='custom'&&<Slider label="Width" min={200} max={2400} step={10} value={o.width} onChange={v=>set({width:v})} unit="px"/>}
      <Checkbox label="Transparent background" checked={o.transparent} onChange={v=>set({transparent:v})}/>
    </Panel>
  </div>;
}
window.EditorScreen=EditorScreen;
