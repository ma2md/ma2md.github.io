# glint — web app UI kit

Stacked 600px column: compact NavBar first, then panels.

Open `index.html`.

- **Scrolls & Banners** (`EditorScreen.jsx`) — Frame / Text / Export tabs; text-only FrameSelector over the five Scrollish styles; multiline text, size, align, colour, shadow; formats Natural / Nexus 1400×400 / Custom width; transparent toggle. Live canvas preview (Fit, 1×–3×), Copy and Export PNG. Settings persist in localStorage.
- **Emotes & Emojis** (`GalleryScreen.jsx`) — one panel, search by number, two sections (Emotes, Emojis) separated by a labelled hairline divider. Sliced from the real sheets with blank-cell filtering and the reference exclusions; 10 animated emotes alternate frames. Click a tile to copy it (currently the PNG; swap `copyLink` for hosted image URLs).
- `lib/scroll-renderer.js`, `lib/sprites.js`, `lib/gif.js` — adapted from the implementation references. Canvases contain only the asset; no UI effects are exported.
