const { Panel: GPanel, TextField: GText, EmojiTile } = window.AteliDoValeDesignSystem_a6a127;
const GBanner=window.AteliDoValeDesignSystem_a6a127.SparkleBanner||(()=>null);
const reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const SECTIONS=[{source:'EmoteMenu',label:'Emotes',zoom:3,size:48,kind:'Emote',links:'emotes'},{source:'emojis',label:'Emojis',zoom:4,size:36,kind:'Emoji',links:'emojis'}];
// Extra animated emojis shipped as GIFs, inserted after emoji #100 to match the Imgur album numbering.
const EXTRA_EMOJIS=[1,2].map(n=>({key:'heart'+n,gif:'../../assets/sprites/heart-animated-'+n+'.gif?v=2',animated:true}));
const withExtras=(source,list)=>source==='emojis'?[...list.slice(0,100),...EXTRA_EMOJIS,...list.slice(100)]:list;
function GalleryDivider({label,count}){
  return <div style={{display:'flex',alignItems:'center',gap:12}}>
    <span className="adv-caps" style={{color:'var(--text-secondary)'}}>{label}</span>
    <span style={{flex:1,height:1,background:'var(--grad-hairline)'}}/>
    <span className="adv-mono" style={{color:'var(--text-faint)'}}>{count}</span>
  </div>;
}
function GalleryScreen({notify}){
  const [ready,setReady]=React.useState(false);
  const [q,setQ]=React.useState('');
  const [frame,setFrame]=React.useState(0);
  const [copied,setCopied]=React.useState(null);
  React.useEffect(()=>{SpriteLib.ready.then(()=>setReady(true)).catch(()=>notify('Couldn’t load the collection.','error'))},[]);
  React.useEffect(()=>{if(reduceMotion)return;const t=setInterval(()=>setFrame(f=>1-f),400);return()=>clearInterval(t)},[]);
  const data=React.useMemo(()=>ready?SECTIONS.map(sec=>({...sec,sprites:withExtras(sec.source,SpriteLib.slice(sec.source).map(s=>({...s,key:sec.source+s.id,urls:(s.animated?[0,1]:[0]).map(f=>SpriteLib.canvasFor(s,sec.zoom,f).toDataURL())}))).map((s,n)=>({...s,num:n+1}))})):[],[ready]);
  // Click copies the sprite's image link (lib/sprite-links.js, same numbering). Falls back to the PNG if no link is set.
  const copyLink=async(s,sec)=>{
    const url=((window.SPRITE_LINKS||{})[sec.links]||[])[s.num-1];
    try{
      if(url){await navigator.clipboard.writeText(url);setCopied(s.key);notify(sec.kind+' '+s.num+' link copied');return}
      if(s.gif){notify('No link for this one yet.','error');return}
      const b=await SpriteLib.toBlob(SpriteLib.canvasFor(s,4,0));await navigator.clipboard.write([new ClipboardItem({'image/png':b})]);setCopied(s.key);notify(sec.kind+' '+s.num+' copied as image')
    }catch{notify('Copy blocked by the browser.','error')}
  };
  const match=s=>!q.trim()||String(s.num).includes(q.trim());
  return <div className="kit-stack">
    <GPanel title="Emotes & Emojis" delay={120} actions={<span className="adv-mono" style={{color:'var(--text-faint)'}}>Click to copy</span>}>
      <GText placeholder="Search by number" value={q} onChange={setQ}/>
      {data.map(sec=>{const list=sec.sprites.filter(match);return <section key={sec.source} style={{display:'flex',flexDirection:'column',gap:10}}>
        <GalleryDivider label={sec.label} count={list.length}/>
        {list.length?<div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(68px,1fr))',gap:6}}>
          {list.map(s=><EmojiTile key={s.key} name={'#'+String(s.num).padStart(3,'0')} code={sec.kind+' '+s.num+' · click to copy'} src={s.gif||s.urls[s.animated?frame:0]} size={sec.size} animated={s.animated} selected={copied===s.key} onClick={()=>copyLink(s,sec)}/>)}
        </div>:<p style={{margin:0,font:'var(--type-body-sm)',color:'var(--text-muted)'}}>No {sec.label.toLowerCase()} match “{q}”.</p>}
      </section>})}
    </GPanel>
  </div>;
}
window.GalleryScreen=GalleryScreen;
